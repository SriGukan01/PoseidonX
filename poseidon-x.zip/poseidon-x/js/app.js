/* ============================================================
   API — talks to the Node/Express + Postgres backend in /server.
   Change API_BASE if the API isn't running on localhost:4000.
============================================================ */
const API_BASE = (window.POSEIDON_API_BASE || "http://localhost:4000") + "/api";

async function apiFetch(path, opts) {
  const res = await fetch(API_BASE + path, {
    headers: { "Content-Type": "application/json" },
    ...opts,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed (${res.status})`);
  }
  return res.status === 204 ? null : res.json();
}

/* ============================================================
   DATA
============================================================ */
const NAV = [
  {key:"home", label:"Home"},
  {key:"dashboard", label:"Dashboard"},
  {key:"scan", label:"AI Scan"},
  {key:"compare", label:"Compare"},
  {key:"leaderboard", label:"Leaderboard"},
  {key:"learn", label:"Learn"},
  {key:"report", label:"Report"},
];

// NOTE: the arrays below (MONITOR_POINTS, ALERTS, LEADERBOARD) are the same
// literal values seeded into Postgres via server/db/seed.sql. They're kept
// here as an instant-render fallback so the UI isn't blank on first paint —
// loadInitialData() overwrites their *contents* in place (via splice) with
// live data fetched from the API as soon as it responds.
const MONITOR_POINTS = [
  {code:"GOA_01", name:"Candolim Coast, Goa", lat:15.5185, lng:73.7629, score:41, status:"poor"},
  {code:"CHE_01", name:"Marina Beach, Chennai", lat:13.0500, lng:80.2824, score:55, status:"fair"},
  {code:"MUM_02", name:"Juhu Shoreline, Mumbai", lat:19.0989, lng:72.8265, score:33, status:"poor"},
  {code:"KOC_01", name:"Vembanad Lake, Kochi", lat:9.5916, lng:76.3949, score:78, status:"good"},
  {code:"KOL_03", name:"Hooghly River, Kolkata", lat:22.5726, lng:88.3639, score:46, status:"fair"},
  {code:"GOA_02", name:"Mandovi Estuary, Goa", lat:15.4989, lng:73.8278, score:71, status:"good"},
  {code:"VIZ_01", name:"RK Beach, Visakhapatnam", lat:17.7231, lng:83.3412, score:62, status:"fair"},
  {code:"DEL_01", name:"Yamuna Ghat, Delhi", lat:28.6139, lng:77.2090, score:24, status:"poor"},
  {code:"SUR_01", name:"Tapi Estuary, Surat", lat:21.1702, lng:72.8311, score:58, status:"fair"},
  {code:"PUR_01", name:"Chilika Lake, Puri", lat:19.7000, lng:85.3200, score:82, status:"good"},
  {code:"AND_01", name:"Radhanagar Beach, Andaman", lat:11.9694, lng:92.7422, score:91, status:"good"},
  {code:"CHE_02", name:"Ennore Creek, Chennai", lat:13.2167, lng:80.3167, score:29, status:"poor"},
];
const STATUS_COLOR = {good:"#12b886", fair:"#f2b134", poor:"#e6553a"};
const STATUS_LABEL = {good:"Good", fair:"Moderate", poor:"High Risk"};
// Radius (px) for station markers on the map - "critical" (poor) shown larger, matching the reference design
const STATUS_RADIUS = {good:6, fair:8, poor:12};

// State-level aggregate water-quality circles, shown as large translucent geo-circles under the station markers
const STATE_CIRCLES = [
  {name:"Goa",              lat:15.40, lng:74.10, status:"fair", radiusM:70000,  note:"Tourism runoff, estuary pollution"},
  {name:"Maharashtra",      lat:19.60, lng:75.70, status:"poor", radiusM:150000, note:"Industrial discharge, urban runoff"},
  {name:"Gujarat",          lat:22.50, lng:71.50, status:"fair", radiusM:150000, note:"Industrial + agricultural inputs"},
  {name:"Delhi NCR",        lat:28.61, lng:77.20, status:"poor", radiusM:60000,  note:"Sewage load, industrial effluent"},
  {name:"West Bengal",      lat:23.30, lng:87.50, status:"fair", radiusM:120000, note:"River sediment, urban discharge"},
  {name:"Odisha",           lat:20.50, lng:84.80, status:"good", radiusM:130000, note:"Stable lagoon health, low industrial load"},
  {name:"Andhra Pradesh",   lat:16.50, lng:80.50, status:"fair", radiusM:150000, note:"Coastal industry, port activity"},
  {name:"Tamil Nadu",       lat:11.80, lng:78.60, status:"poor", radiusM:150000, note:"Tourism impact, backwater pollution"},
  {name:"Kerala",           lat:10.20, lng:76.30, status:"good", radiusM:110000, note:"Tourism impact, backwater pollution, agricultural chemicals"},
  {name:"Andaman & Nicobar",lat:11.70, lng:92.70, status:"good", radiusM:100000, note:"Pristine coastline, minimal industry"},
];

const INDIA_VIEW = {center:[22.5, 80.5], zoom:5};
const WORLD_VIEW = {center:[20, 15], zoom:2};

const ALERTS = [
  {title:"Microplastic Spike", level:"HIGH", body:"Elevated microplastic density detected along Candolim Coast. Possible runoff after monsoon.", code:"GOA_01", hours:3, duration:"22h", icon:"flask"},
  {title:"Turbidity Increase", level:"HIGH", body:"Increased turbidity levels at Ennore Creek. Possible industrial contamination.", code:"CHE_02", hours:6, duration:"18h", icon:"droplet"},
  {title:"Temperature Rise", level:"MEDIUM", body:"Thermal pollution flagged at Marina Beach. Industrial discharge suspected nearby.", code:"CHE_01", hours:7, duration:"30h", icon:"sun"},
  {title:"pH Imbalance", level:"MEDIUM", body:"Yamuna Ghat readings show sustained pH drop below safe threshold for aquatic life.", code:"DEL_01", hours:9, duration:"40h", icon:"alert"},
  {title:"Water Quality Improving", level:"LOW", body:"Chilika Lake shows a steady rise in dissolved oxygen after cleanup drive.", code:"PUR_01", hours:14, duration:"—", icon:"shield"},
];

// Extra candidate alerts the live-data tick can rotate in to simulate a real-time feed
const ALERT_POOL = [
  {title:"Dissolved Oxygen Drop", level:"HIGH", body:"DO levels falling sharply near Juhu Shoreline. Possible organic pollution event.", code:"MUM_02", hours:0, duration:"20h", icon:"droplet"},
  {title:"Salinity Fluctuation", level:"MEDIUM", body:"Unusual salinity swing detected at Vembanad Lake. Monitoring for tidal or discharge cause.", code:"KOC_01", hours:0, duration:"16h", icon:"flask"},
  {title:"Algal Bloom Risk", level:"MEDIUM", body:"Nutrient levels near Hooghly River trending toward bloom conditions.", code:"KOL_03", hours:0, duration:"36h", icon:"alert"},
  {title:"Sensor Recalibrated", level:"LOW", body:"RK Beach buoy recalibrated after routine maintenance; readings now stable.", code:"VIZ_01", hours:0, duration:"—", icon:"shield"},
  {title:"Oil Sheen Reported", level:"HIGH", body:"Citizen report flags a visible oil sheen near Tapi Estuary. Field team dispatched.", code:"SUR_01", hours:0, duration:"12h", icon:"droplet"},
];

const LEADERBOARD = [
  {rank:1, name:"Aarav Mehta", region:"Goa", points:4820, reports:61},
  {rank:2, name:"Priya Nair", region:"Kochi", points:4390, reports:54},
  {rank:3, name:"Team Ganga Rakshak", region:"Delhi NCR", points:4110, reports:49},
  {rank:4, name:"Sanjay Iyer", region:"Chennai", points:3765, reports:45},
  {rank:5, name:"Coastal Watch Odisha", region:"Puri", points:3420, reports:40},
  {rank:6, name:"Meera Krishnan", region:"Visakhapatnam", points:3180, reports:37},
];

const LEARN_TOPICS = [
  {title:"What is turbidity, really?", tag:"Basics", read:"6 min", art:"turbidity", body:"How suspended particles scatter light, and why cloudy water is an early-warning signal.",
    full:[
      {h:"The basic idea", p:"Turbidity is simply a measure of how cloudy or hazy water looks, caused by large numbers of tiny particles that are usually invisible individually — silt, clay, algae, organic matter, and industrial or urban runoff. Instruments measure it by shining a light through a water sample and recording how much of that light scatters off the suspended particles rather than passing straight through, reported in units called NTU (nephelometric turbidity units)."},
      {h:"Why it's an early-warning signal", p:"Turbidity often rises before other problems become obvious. A sudden spike after rainfall can point to erosion or sewage overflow, while a steady climb over weeks can flag construction runoff or an algal bloom taking hold. Because suspended particles can also shield bacteria and viruses from disinfection and can carry attached pollutants like heavy metals, high turbidity is treated as a proxy risk indicator even when it isn't harmful on its own."},
      {h:"What typically causes it", list:[
        "Storm runoff carrying soil and silt from bare or eroded land",
        "Algal blooms fed by excess nutrients from fertiliser or sewage",
        "Construction, dredging, or riverbank disturbance",
        "Industrial discharge and untreated wastewater"
      ]},
      {h:"How to read the number", p:"Under roughly 5 NTU is considered clear; 5–50 NTU is noticeably cloudy but common after rain; above 50 NTU usually signals a real event worth investigating. Context matters more than a single reading — a river that's naturally silty after monsoon rain behaves very differently from a normally clear lake that suddenly turns murky."},
      {h:"The takeaway", p:"Clear water isn't automatically safe, and cloudy water isn't automatically dangerous — but turbidity is cheap and fast to measure, which is why it's one of the first numbers monitoring networks like this one watch closely, alongside pH, dissolved oxygen and temperature."}
    ]},
  {title:"Microplastics in coastal waters", tag:"Deep dive", read:"8 min", art:"microplastics", body:"Where they come from, how our sensors detect them, and what the concentration levels mean.",
    full:[
      {h:"Where they come from", p:"Microplastics are plastic fragments smaller than 5mm that enter waterways from a wide range of sources: synthetic clothing fibres shed during washing, tyre wear washed off roads, breakdown of larger litter under sun and waves, cosmetic microbeads, and fragments escaping from packaging and fishing gear. Coastal zones tend to accumulate them because currents, tides and river outflows all converge there."},
      {h:"Two broad categories", list:[
        "Primary microplastics — manufactured small, like microbeads or pellets, released directly into water",
        "Secondary microplastics — fragments that break off larger plastic items over time through sunlight, waves and abrasion"
      ]},
      {h:"How detection works", p:"Detecting microplastics in the field is hard because the particles are small, irregularly shaped, and easily confused with sediment or organic debris. Approaches typically combine physical filtering of a water sample down to a known particle size, followed by optical or spectroscopic analysis — shining specific light wavelengths at particles and reading how they scatter or absorb it — to distinguish plastic polymers from natural material. Buoy-style sensors use a simplified version of this: a laser-scatter chamber that estimates particle density in-situ without needing a lab sample, trading some precision for speed and continuous monitoring."},
      {h:"Reading the concentration", p:"Concentration is usually expressed as particle count per cubic metre or per litre. Low counts are common even in relatively clean water because plastics are now ubiquitous globally; what matters more for interpretation is the trend over time and sudden spikes, which can indicate a nearby discharge point, a storm-driven flush of urban runoff, or a shipping or fishing-related event worth investigating further."},
      {h:"Why it matters ecologically", p:"Small marine organisms can mistake microplastic fragments for food, and the particles can carry adsorbed pollutants up the food chain as larger animals eat smaller ones. Coastal and estuarine habitats — nurseries for many fish species — are especially exposed because that's exactly where land-based plastic pollution first meets the sea."}
    ]},
  {title:"Reading a water quality score", tag:"Basics", read:"5 min", art:"score", body:"A walkthrough of the 0–100 score: what pH, TDS, DO and temperature each contribute.",
    full:[
      {h:"What goes into it", p:"A composite water-quality score condenses several separate readings into one 0–100 number so it's easy to scan at a glance. The usual ingredients are pH, dissolved oxygen (DO), total dissolved solids (TDS), and temperature."},
      {h:"The four core parameters", list:[
        "pH — how acidic or alkaline the water is; most aquatic life is happiest close to neutral, roughly 6.5–8.5",
        "Dissolved oxygen (DO) — oxygen available for fish and other organisms; low DO often signals organic pollution or an algal bloom consuming oxygen as it decays",
        "Total dissolved solids (TDS) — the combined concentration of dissolved minerals, salts and some pollutants",
        "Temperature — affects how much oxygen water can hold and how fast organisms and chemical reactions behave"
      ]},
      {h:"How the blend works", p:"Each of these is typically normalised against a healthy reference range and then blended into a single index — sometimes with equal weighting, sometimes weighting the parameters most relevant to the local ecosystem more heavily."},
      {h:"What the number means", p:"A score in the 70s or above generally reflects water that's close to natural, undisturbed conditions; the 45–69 range suggests moderate stress from one or more parameters drifting outside ideal bounds; and scores below 45 usually mean at least one parameter — often DO or a contaminant proxy — has moved sharply out of range and warrants closer attention."},
      {h:"A summary, not a diagnosis", p:"Two very different problems — say, an oxygen crash from algae versus a chemical spill affecting pH — can produce similar-looking scores, which is why the underlying readings and trend are worth checking alongside the headline number."}
    ]},
  {title:"Filing a report that gets acted on", tag:"Guide", read:"6 min", art:"report", body:"The details that help responders triage fast — location precision, photos, and timing.",
    full:[
      {h:"Why detail matters", p:"Environmental responders typically triage incoming reports by urgency and credibility, and both depend heavily on how much specific, checkable detail a report includes."},
      {h:"Location beats description", p:"The single most useful thing you can provide is precise location — a dropped pin or GPS coordinate beats a written description of a place every time, because it lets a team find the exact spot without guesswork, especially along a long coastline or riverbank where 'near the bridge' could mean several different bridges."},
      {h:"What a good report includes", list:[
        "A dropped pin or GPS coordinate, not just a place name",
        "A wide shot and a close-up photo, ideally with something in frame for scale",
        "When you first noticed it, and whether it's ongoing, worsening, or dispersing",
        "Anything distinctive — smell, colour, foam, dead or distressed wildlife"
      ]},
      {h:"Why photos help", p:"Photos and short video add a lot of credibility and help responders assess severity before they even arrive — a visible oil sheen, dead fish, discoloured water or unusual foam are all things a photo communicates faster than text."},
      {h:"Timing changes everything", p:"Some pollution events, like a sheen or a discharge, can change rapidly and responders need to know if they're chasing something that will still be there. A plain description of anything distinctive rounds out the picture and helps responders decide what kind of team and equipment to send."}
    ]},
];

const FEATURES = [
  {icon:"radar", title:"Real-time Monitoring", body:"Live water quality metrics including pH, turbidity, temperature, and TDS levels.", nav:"dashboard"},
  {icon:"flask", title:"Microplastic Detection", body:"AI-powered analysis of microplastic particles in water samples.", nav:"scan"},
  {icon:"pin", title:"Interactive Maps", body:"Colour-coded pollution zones and monitoring station locations.", nav:"dashboard"},
  {icon:"bell", title:"Smart Alerts", body:"Predictive alerts for contamination spikes and environmental threats.", nav:"dashboard"},
  {icon:"scan", title:"AI Photo Scan", body:"Snap or upload a water sample photo and get an instant clarity & contaminant read.", nav:"scan"},
  {icon:"trend", title:"3-Day Forecasting", body:"Trend models project where each station's water quality score is headed.", nav:"dashboard"},
];

/* ---------- BADGES / GAMIFICATION ---------- */
const BADGES = [
  {icon:"send", name:"First Report", desc:"Filed a report", earned:true},
  {icon:"flame", name:"7-Day Streak", desc:"Reported 7 days running", earned:true},
  {icon:"shield", name:"Eco Warrior", desc:"25+ verified reports", earned:true},
  {icon:"trophy", name:"Top 10", desc:"Ranked in region top 10", earned:false},
  {icon:"radar", name:"Data Guardian", desc:"100+ readings reviewed", earned:false},
];

/* ---------- SDG / IMPACT ---------- */
const SDGS = [
  {num:"SDG 6", name:"Clean Water & Sanitation", desc:"Real-time monitoring flags unsafe water before communities are exposed.", color:"#0aa88f"},
  {num:"SDG 14", name:"Life Below Water", desc:"Early microplastic and contamination detection protects marine ecosystems.", color:"#1c6dd0"},
  {num:"SDG 13", name:"Climate Action", desc:"Long-term trend data reveals climate-linked shifts in water quality.", color:"#0b2545"},
  {num:"SDG 11", name:"Sustainable Cities", desc:"City planners get an early-warning layer for urban waterway health.", color:"#0c9c85"},
  {num:"SDG 3", name:"Good Health & Well-being", desc:"Citizens avoid contaminated sites flagged as high risk in real time.", color:"#1c6dd0"},
  {num:"SDG 17", name:"Partnerships for the Goals", desc:"Open citizen-reporting turns every resident into a monitoring node.", color:"#0b2545"},
];

const HARDWARE = [
  {icon:"cpu", title:"Poseidon Buoy v2", body:"Solar-powered floating sensor pod: pH, turbidity, TDS, temperature & dissolved oxygen probes, LoRa + GSM uplink."},
  {icon:"flask", title:"Microplastic Cell", body:"Laser-scatter chamber estimates particle density in-situ, no lab sample required."},
  {icon:"radar", title:"Edge AI Module", body:"On-buoy inference flags anomalies instantly and only syncs summarised readings to save power."},
];

const TEAM = [
  {name:"Sri Gukan J", role:"Full-stack + IoT"},
  {name:"Seema Jahan H Y", role:"ML / Computer Vision"},
  {name:"Snikitha K", role:"Hardware / Embedded"},
  {name:"Vishaal S", role:"Product / Design"},
];

/* ---------- SYNTHETIC HISTORY + FORECAST (deterministic pseudo-random) ---------- */
function seeded(seed){ let s = seed % 2147483647; if(s<=0) s+=2147483646;
  return function(){ s = (s*16807) % 2147483647; return (s-1)/2147483646; }; }

// stationHistory() below is backed by GET /api/stations/:code/history — the
// backend computes it with the exact same PRNG so values match once loaded.
// historyCache holds whatever the API has returned so far; localStationHistory
// is the same deterministic generator, kept only as a fallback so charts
// aren't empty during the brief window before the first fetch resolves.
const historyCache = {};
function stationHistory(station){
  if(historyCache[station.code]) return historyCache[station.code];
  fetchStationHistory(station.code); // fire-and-forget; re-renders on arrival
  return localStationHistory(station);
}
async function fetchStationHistory(code){
  if(historyCache[code] || historyCache["__pending_"+code]) return;
  historyCache["__pending_"+code] = true;
  try{
    const data = await apiFetch(`/stations/${code}/history`);
    historyCache[code] = { hist:data.hist, forecast:data.forecast, slope:data.slope };
    if(currentPage==="dashboard" || currentPage==="compare") render();
  }catch(e){
    console.warn("Falling back to local history for", code, e.message);
  }finally{
    delete historyCache["__pending_"+code];
  }
}
function localStationHistory(station){
  const rnd = seeded(station.code.split("").reduce((a,c)=>a+c.charCodeAt(0),0) + station.score);
  const days = 14;
  let val = station.score + (rnd()*10-5);
  const hist = [];
  for(let i=days;i>0;i--){
    val += (rnd()*10-5);
    val = Math.max(8, Math.min(97, val));
    hist.push(Math.round(val));
  }
  hist[hist.length-1] = station.score;
  // simple linear trend from last 6 points -> 3-day forecast
  const tail = hist.slice(-6);
  const n = tail.length;
  const xs = tail.map((_,i)=>i);
  const xbar = xs.reduce((a,b)=>a+b,0)/n, ybar = tail.reduce((a,b)=>a+b,0)/n;
  let num=0, den=0;
  for(let i=0;i<n;i++){ num += (xs[i]-xbar)*(tail[i]-ybar); den += (xs[i]-xbar)**2; }
  const slope = den===0 ? 0 : num/den;
  const forecast = [];
  let last = hist[hist.length-1];
  for(let i=1;i<=3;i++){ last = Math.max(5, Math.min(99, last + slope)); forecast.push(Math.round(last)); }
  return {hist, forecast, slope};
}

/* ---------- Lightweight inline-SVG line chart (no external chart library needed) ---------- */
function buildLineChartSVG(seriesList, opts={}){
  const width = opts.width || 600, height = opts.height || 220;
  const padL = 10, padR = 10, padT = 16, padB = 16;
  const min = opts.min!==undefined ? opts.min : 0, max = opts.max!==undefined ? opts.max : 100;
  const n = Math.max(...seriesList.map(s=>s.data.length));
  const xAt = i => padL + (n<=1 ? 0 : i*(width-padL-padR)/(n-1));
  const yAt = v => (height-padB) - ((v-min)/(max-min))*(height-padT-padB);
  const gridLines = [0,25,50,75,100].map(g=>`<line x1="${padL}" x2="${width-padR}" y1="${yAt(g).toFixed(1)}" y2="${yAt(g).toFixed(1)}" stroke="var(--line)" stroke-width="1"/>`).join("");
  const body = seriesList.map(s=>{
    const pts = s.data.map((v,i)=>[xAt(i), yAt(v)]);
    const dashFrom = s.dashFrom!==undefined ? s.dashFrom : pts.length-1;
    const solidPts = pts.slice(0, dashFrom+1);
    const dashPts = pts.slice(dashFrom);
    const toPath = arr => arr.length ? "M"+arr.map(p=>`${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" L") : "";
    let fillEl = "";
    if(s.fill && solidPts.length>1){
      const base = (height-padB).toFixed(1);
      fillEl = `<path d="${toPath(solidPts)} L${solidPts[solidPts.length-1][0].toFixed(1)},${base} L${solidPts[0][0].toFixed(1)},${base} Z" fill="${s.color}" fill-opacity="0.12" stroke="none"/>`;
    }
    const solidEl = solidPts.length>1 ? `<path d="${toPath(solidPts)}" fill="none" stroke="${s.color}" stroke-width="2.75" stroke-linecap="round" stroke-linejoin="round"/>` : "";
    const dashEl = dashPts.length>1 ? `<path d="${toPath(dashPts)}" fill="none" stroke="${s.color}" stroke-width="2.75" stroke-dasharray="6 5" stroke-linecap="round" stroke-linejoin="round"/>` : "";
    const lastPt = pts[pts.length-1];
    const dotEl = `<circle cx="${lastPt[0].toFixed(1)}" cy="${lastPt[1].toFixed(1)}" r="4.5" fill="${s.color}" stroke="#fff" stroke-width="2"/>`;
    return fillEl + solidEl + dashEl + dotEl;
  }).join("");
  return `<svg viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" style="width:100%;height:100%;display:block;">${gridLines}${body}</svg>`;
}

function trendChartSVG(station){
  const {hist, forecast} = stationHistory(station);
  return buildLineChartSVG([
    { data:[...hist, ...forecast], color:STATUS_COLOR[station.status], dashFrom:hist.length-1, fill:true }
  ], {height:220});
}

function compareChartSVG(a,b){
  const ha = stationHistory(a), hb = stationHistory(b);
  const chart = buildLineChartSVG([
    { data:[...ha.hist, ...ha.forecast], color:"#1c6dd0", dashFrom:ha.hist.length-1 },
    { data:[...hb.hist, ...hb.forecast], color:"#0aa88f", dashFrom:hb.hist.length-1 },
  ], {height:230});
  const legend = `
    <div class="chart-legend">
      <span><i style="background:#1c6dd0"></i>${a.name}</span>
      <span><i style="background:#0aa88f"></i>${b.name}</span>
      <span class="chart-legend-note">Solid = last 14 days · Dashed = 3-day forecast</span>
    </div>`;
  return `<div class="chart-svg-wrap">${chart}</div>${legend}`;
}

/* ---------- AI SCAN presets (deterministic mock "AI" results) ---------- */
const SCAN_PRESETS = [
  {key:"clear", label:"Clear coastal water", grad:"linear-gradient(135deg,#8fd3d9,#3aa8c1)", clarity:88, turbidity:"Low", contaminants:["None significant"], risk:"low"},
  {key:"murky", label:"Murky / sediment-heavy", grad:"linear-gradient(135deg,#c9a15c,#8a6a3a)", clarity:34, turbidity:"High", contaminants:["Suspended sediment","Possible runoff"], risk:"med"},
  {key:"sheen", label:"Oil sheen suspected", grad:"linear-gradient(135deg,#5a5a3c,#22261b)", clarity:19, turbidity:"High", contaminants:["Hydrocarbon sheen","Surface film"], risk:"high"},
];

/* ============================================================
   ICONS (inline SVG strings)
============================================================ */
const ICONS = {
  radar: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19.07 4.93A10 10 0 1 0 22 12"/><path d="M12 12 8 8"/><circle cx="12" cy="12" r="1"/><path d="M12 2v2"/><path d="M12 12 21 8"/></svg>',
  flask: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 2v6.5L4.5 18a2 2 0 0 0 1.8 3h11.4a2 2 0 0 0 1.8-3L14 8.5V2"/><path d="M8.5 2h7"/><path d="M7 16h10"/></svg>',
  pin: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>',
  bell: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>',
  droplet: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2.7s6 7.4 6 11.8a6 6 0 0 1-12 0c0-4.4 6-11.8 6-11.8Z"/></svg>',
  sun: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 3v1M12 20v1M4.2 4.2l.7.7M19.1 19.1l.7.7M3 12h1M20 12h1M4.2 19.8l.7-.7M19.1 4.9l.7-.7"/></svg>',
  alert: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.3 3.9 1.9 18a2 2 0 0 0 1.7 3h16.8a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
  shield: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/></svg>',
  sparkle: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M18.4 5.6l-2.8 2.8M8.4 15.6l-2.8 2.8"/></svg>',
  arrowUp: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M7 17 17 7"/><path d="M7 7h10v10"/></svg>',
  send: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>',
  trophy: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#e6a020" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0V4Z"/><path d="M17 5h3a2 2 0 0 1-2 4M7 5H4a2 2 0 0 0 2 4"/></svg>',
  book: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1c6dd0" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"/></svg>',
  chevron: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>',
  scan: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2"/><circle cx="12" cy="12" r="3"/><path d="M3 12h2M19 12h2"/></svg>',
  trend: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 17 6-6 4 4 8-8"/><path d="M17 7h4v4"/></svg>',
  flame: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2s-6 6-6 12a6 6 0 0 0 12 0c0-2-1-3-1-3s-1 2-2.5 2c-2 0-2-2-2-3.5C12.5 7 12 2 12 2Z"/></svg>',
  cpu: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/></svg>',
  upload: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 16v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"/></svg>',
  location: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>',
  mic: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0M12 19v3"/></svg>',
  download: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12M6 11l6 6 6-6"/><path d="M5 21h14"/></svg>',
  close: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg>',
};

/* ============================================================
   ROUTER
============================================================ */
let currentPage = "home";
let mapView = "asia"; // "asia" | "world"
let darkMode = false;
let notifOpen = false;
let botOpen = false;
let botMessages = [
  {who:"bot", text:"Hi, I'm AquaBot 🌊 Ask me about water quality scores, alerts, or how to file a report."}
];
let trendStationCode = MONITOR_POINTS[0].code;
let compareCodes = [MONITOR_POINTS[0].code, MONITOR_POINTS[2].code];
let scanState = {img:null, analyzing:false, progress:0, result:null, presetKey:null};
let dashSearch = "";

function navigate(page){
  if(page !== "learn") openLearnIndex = null;
  currentPage = page;
  window.scrollTo({top:0, behavior:"instant"});
  render();
}

function buildNav(){
  const links = document.getElementById("navLinks");
  const mobile = document.getElementById("navMobile");
  links.innerHTML = "";
  mobile.innerHTML = "";
  NAV.forEach(n=>{
    const b = document.createElement("button");
    b.className = "nav-link" + (currentPage===n.key ? " active":"");
    b.textContent = n.label;
    b.onclick = ()=>{ navigate(n.key); document.getElementById("navMobile").classList.remove("open"); };
    links.appendChild(b);

    const bm = b.cloneNode(true);
    bm.onclick = ()=>{ navigate(n.key); document.getElementById("navMobile").classList.remove("open"); };
    mobile.appendChild(bm);
  });
}
document.getElementById("navToggle").onclick = ()=> document.getElementById("navMobile").classList.toggle("open");
document.querySelector(".logo").onclick = ()=> navigate("home");
document.querySelectorAll("footer [data-nav]").forEach(el=> el.addEventListener("click", ()=> navigate(el.dataset.nav)));

/* ============================================================
   PAGE RENDERERS
============================================================ */
function renderHome(){
  return `
    <section class="hero">
      <div class="hero-inner">
        <span class="pill">${ICONS.sparkle} Live across 12 monitoring zones</span>
        <h1>See the health of your waters, before it becomes a crisis.</h1>
        <p>Poseidon X streams live water-quality readings, flags contamination early, and turns every citizen report into action — one coastline, lake, and river at a time.</p>
        <div class="hero-actions">
          <button class="btn btn-primary" data-nav="dashboard">Open Dashboard ${ICONS.arrowUp}</button>
          <button class="btn btn-ghost" data-nav="report">Report Pollution</button>
        </div>
      </div>
    </section>

    <section class="features">
      <div class="feature-grid">
        ${FEATURES.map(f=>`
          <div class="card card-module" data-nav="${f.nav}" role="button" tabindex="0">
            <div class="feature-icon">${ICONS[f.icon]}</div>
            <h3>${f.title}</h3>
            <p>${f.body}</p>
          </div>`).join("")}
      </div>
    </section>

    <section class="stats">
      <div><div class="stat-num">12</div><div class="stat-label">Active monitoring zones</div></div>
      <div><div class="stat-num">1,940+</div><div class="stat-label">Citizen reports filed</div></div>
      <div><div class="stat-num">63</div><div class="stat-label">Contamination events caught early</div></div>
    </section>
  `;
}

function renderDashboard(){
  const avg = Math.round(MONITOR_POINTS.reduce((s,p)=>s+p.score,0)/MONITOR_POINTS.length);
  const poor = MONITOR_POINTS.filter(p=>p.status==="poor").length;
  const q = dashSearch.trim().toLowerCase();
  const filtered = q ? MONITOR_POINTS.filter(p=>p.name.toLowerCase().includes(q) || p.code.toLowerCase().includes(q)) : null;
  return `
    <div class="page">
      <div class="page-head">
        <div>
          <h1>Live Mapping</h1>
          <div class="page-sub"><span class="live-dot"></span> &nbsp;Real-time water quality across all monitoring zones · <span id="freshTick">Updated just now</span></div>
        </div>
        <button class="export-btn" id="exportBtn">${ICONS.download} Export CSV</button>
      </div>
      <div class="stat-cards">
        <div class="stat-card tick"><div class="label">Average score</div><div class="value" id="avgScoreVal">${avg}</div><div class="sub">Across ${MONITOR_POINTS.length} zones</div></div>
        <div class="stat-card tick"><div class="label">Zones needing attention</div><div class="value" id="zonesAttentionVal" style="color:var(--poor)">${poor}</div><div class="sub">Poor water quality</div></div>
        <div class="stat-card tick"><div class="label">Active alerts</div><div class="value" id="activeAlertsVal" style="color:var(--blue)">${ALERTS.length}</div><div class="sub" id="activeAlertsSub">Updated a few minutes ago</div></div>
      </div>
      <div class="search-row">
        <input type="text" id="dashSearch" placeholder="Search a station by name or code…" value="${dashSearch}" />
      </div>
      ${filtered ? `
        <div class="panel" style="margin-bottom:20px;">
          <div class="panel-head"><h2>${filtered.length} station${filtered.length===1?'':'s'} found</h2></div>
          <div style="padding:6px 20px 16px;">
            ${filtered.length ? filtered.map(p=>`
              <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--line);">
                <div><div style="font-weight:700;font-size:13.5px;">${p.name}</div><div style="font-size:11px;color:var(--ink-faint);font-family:ui-monospace,monospace;">${p.code}</div></div>
                <div style="font-weight:800;color:${STATUS_COLOR[p.status]}">${p.score}</div>
              </div>`).join("") : `<div class="page-sub">No stations match "${dashSearch}".</div>`}
          </div>
        </div>` : ``}
      <div class="dash-grid">
        <div class="panel">
          <div class="panel-head" style="flex-wrap:wrap;gap:10px;">
            <h2>Live Pollution Map — India Focus</h2>
            <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
              <div class="map-toggle" id="mapToggle">
                <button type="button" class="map-toggle-btn ${mapView==='asia'?'active':''}" data-view="asia">India Focus</button>
                <button type="button" class="map-toggle-btn ${mapView==='world'?'active':''}" data-view="world">World</button>
              </div>
              <div class="legend-group">
                <span class="legend-title">State Water Quality</span>
                <div class="legend">
                  <span><span class="dot" style="background:var(--good)"></span>Good</span>
                  <span><span class="dot" style="background:var(--fair)"></span>Moderate</span>
                  <span><span class="dot" style="background:var(--poor)"></span>High Risk</span>
                </div>
              </div>
              <div class="legend-group">
                <span class="legend-title">Monitoring Stations</span>
                <div class="legend">
                  <span><span class="dot" style="background:var(--good);width:7px;height:7px;"></span>Low</span>
                  <span><span class="dot" style="background:var(--fair);width:9px;height:9px;"></span>Medium</span>
                  <span><span class="dot" style="background:var(--poor);width:13px;height:13px;"></span>Critical</span>
                </div>
              </div>
            </div>
          </div>
          <div class="map-wrap">
            <div id="leafletMap"></div>
          </div>
        </div>
        <div class="panel">
          <div class="panel-head"><h2>Smart Alerts</h2></div>
          <div class="alerts-list" id="smartAlertsList">
            ${ALERTS.map(a=>alertItemHTML(a)).join("")}
          </div>
        </div>
      </div>
      <div class="panel trend-panel">
        <div class="trend-head-row">
          <h2>Trend & 3-Day Forecast</h2>
          <select class="select-pill" id="trendStationSelect">
            ${MONITOR_POINTS.map(p=>`<option value="${p.code}" ${p.code===trendStationCode?'selected':''}>${p.name}</option>`).join("")}
          </select>
        </div>
        <div id="trendSummary">${trendSummaryHTML(MONITOR_POINTS.find(p=>p.code===trendStationCode) || MONITOR_POINTS[0])}</div>
        <div class="trend-canvas-wrap" id="trendChartWrap">${trendChartSVG(MONITOR_POINTS.find(p=>p.code===trendStationCode) || MONITOR_POINTS[0])}</div>
      </div>
    </div>
  `;
}

function alertItemHTML(a){
  return `
    <div class="alert alert-${a.level}">
      <div class="alert-top">
        <div class="alert-title">${ICONS[a.icon]} ${a.title}</div>
        <span class="badge badge-${a.level}">${a.level}</span>
      </div>
      <div class="alert-body">${a.body}</div>
      <div class="alert-meta">
        <span class="loc">${ICONS.pin.replace('width="20" height="20"','width="12" height="12"')} ${a.code}</span>
        <span>${a.hours}h ago · Est. duration: ${a.duration}</span>
      </div>
    </div>`;
}

function scoreToStatus(score){
  return score>=70 ? "good" : score>=45 ? "fair" : "poor";
}

function trendSummaryHTML(st){
  const {forecast, slope} = stationHistory(st);
  const dir = slope>=0.15 ? "rising" : slope<=-0.15 ? "falling" : "holding steady";
  const dirColor = slope>=0.15 ? "var(--good)" : slope<=-0.15 ? "var(--poor)" : "var(--ink-soft)";
  return `
    <div class="trend-summary">
      <div class="trend-summary-area">
        <span class="loc">${ICONS.pin.replace('width="20" height="20"','width="13" height="13"')} ${st.name}</span>
        <span class="trend-summary-now">Current score: <strong style="color:${STATUS_COLOR[st.status]}">${st.score}</strong> · ${STATUS_LABEL[st.status]}</span>
      </div>
      <div class="trend-summary-forecast">
        <span class="trend-summary-dir" style="color:${dirColor}">Trend ${dir}</span>
        ${forecast.map((v,i)=>`<span class="trend-chip">Day +${i+1}: <strong>${v}</strong></span>`).join("")}
      </div>
    </div>`;
}

function attachDashboardEvents(){
  const search = document.getElementById("dashSearch");
  if(search) search.addEventListener("input", (e)=>{ dashSearch = e.target.value; render(); });
  const trendSel = document.getElementById("trendStationSelect");
  if(trendSel) trendSel.onchange = ()=>{
    trendStationCode = trendSel.value;
    const st = MONITOR_POINTS.find(p=>p.code===trendStationCode) || MONITOR_POINTS[0];
    const summaryEl = document.getElementById("trendSummary");
    if(summaryEl) summaryEl.innerHTML = trendSummaryHTML(st);
    const chartEl = document.getElementById("trendChartWrap");
    if(chartEl) chartEl.innerHTML = trendChartSVG(st);
  };
  const exportBtn = document.getElementById("exportBtn");
  if(exportBtn) exportBtn.onclick = ()=>{
    const rows = [["code","name","lat","lng","score","status"], ...MONITOR_POINTS.map(p=>[p.code,p.name,p.lat,p.lng,p.score,p.status])];
    const csv = rows.map(r=>r.map(c=>`"${c}"`).join(",")).join("\n");
    const blob = new Blob([csv], {type:"text/csv"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "poseidon-x-stations.csv";
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };
}

let leafletMapInstance = null;

function attachMapEvents(){
  const container = document.getElementById("leafletMap");
  if(!container || typeof L === "undefined") return;

  const view = mapView === "world" ? WORLD_VIEW : INDIA_VIEW;
  const map = L.map(container, { scrollWheelZoom:false }).setView(view.center, view.zoom);
  leafletMapInstance = map;

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors',
    maxZoom: 18
  }).addTo(map);

  // Layer 1: large translucent state-level water-quality circles
  STATE_CIRCLES.forEach(s=>{
    const color = STATUS_COLOR[s.status];
    L.circle([s.lat, s.lng], {
      radius: s.radiusM,
      color: color,
      weight: 1.5,
      fillColor: color,
      fillOpacity: 0.16,
    }).addTo(map).bindPopup(`
      <div class="lp-state">${s.name}</div>
      <div class="lp-state-status" style="color:${color}">${STATUS_LABEL[s.status]}</div>
      <div class="lp-score-row" style="margin-top:6px;"><span>${s.note}</span></div>
    `);
  });

  // Layer 2: individual monitoring station markers, sized/coloured by severity
  MONITOR_POINTS.forEach(p=>{
    const color = STATUS_COLOR[p.status];
    L.circleMarker([p.lat, p.lng], {
      radius: STATUS_RADIUS[p.status],
      color: "#fff",
      weight: 2,
      fillColor: color,
      fillOpacity: 0.95,
    }).addTo(map).bindPopup(`
      <div class="lp-code">${p.code}</div>
      <div class="lp-name">${p.name}</div>
      <div class="lp-score-row"><span>Score</span><span class="lp-score-val" style="color:${color}">${p.score}</span></div>
    `);
  });

  const toggle = document.getElementById("mapToggle");
  if(toggle){
    toggle.querySelectorAll(".map-toggle-btn").forEach(btn=>{
      btn.addEventListener("click", ()=>{
        if(mapView === btn.dataset.view) return;
        mapView = btn.dataset.view;
        render();
      });
    });
  }
}

function renderLeaderboard(){
  return `
    <div class="page page-narrow">
      <div class="title-row">${ICONS.trophy}<h1>Leaderboard</h1></div>
      <div class="page-sub" style="margin-bottom:20px;">Top contributors keeping their local waters accountable this month.</div>
      <div style="font-size:12.5px;font-weight:800;color:var(--ink-soft);margin-bottom:10px;">YOUR BADGES</div>
      <div class="badges-strip">
        ${BADGES.map(b=>`
          <div class="badge-card ${b.earned?'':'locked'}">
            <div class="badge-ic">${ICONS[b.icon]}</div>
            <div class="bname">${b.name}</div>
            <div class="bdesc">${b.desc}</div>
          </div>`).join("")}
      </div>
      <div class="lb-list">
        ${LEADERBOARD.map(r=>`
          <div class="lb-row">
            <div class="lb-rank ${r.rank<=3?'top':''}">${r.rank}</div>
            <div class="lb-flex">
              <div class="lb-name">${r.name}</div>
              <div class="lb-region">${ICONS.pin.replace('width="20" height="20"','width="11" height="11"')} ${r.region} · ${r.reports} reports</div>
            </div>
            <div>
              <div class="lb-points">${r.points.toLocaleString()}</div>
              <div class="lb-points-label" style="text-align:right;">eco-points</div>
            </div>
          </div>`).join("")}
      </div>
    </div>
  `;
}

function renderLearn(){
  return `
    <div class="page">
      <div class="title-row">${ICONS.book}<h1>Learn</h1></div>
      <div class="page-sub" style="margin-bottom:24px;">Short reads to help you understand what the readings actually mean.</div>
      <div class="learn-grid">
        ${LEARN_TOPICS.map((t,i)=>`
          <div class="learn-card">
            <div class="learn-card-art">${learnArtSVG(t.art, true)}</div>
            <span class="learn-tag">${t.tag}</span>
            <h3>${t.title}</h3>
            <p>${t.body}</p>
            <div class="learn-foot">
              <span class="learn-read">${t.read} read</span>
              <button type="button" class="learn-cta" data-learn-index="${i}">Read ${ICONS.chevron}</button>
            </div>
          </div>`).join("")}
      </div>
    </div>
  `;
}

/* ---------- Original inline-SVG illustrations for the Learn module (no external images) ---------- */
function learnArtSVG(key, compact){
  const h = compact ? 120 : 200;
  const bg = `<rect width="600" height="${h}" fill="var(--blue-bg)"/>`;
  if(key==="turbidity"){
    return `<svg viewBox="0 0 600 ${h}" preserveAspectRatio="xMidYMid slice" style="width:100%;height:100%;display:block;">
      ${bg}
      <path d="M0,${h*0.35} C120,${h*0.25} 200,${h*0.45} 320,${h*0.35} C440,${h*0.25} 500,${h*0.45} 600,${h*0.35} L600,${h} L0,${h} Z" fill="#bcdff0"/>
      <path d="M0,${h*0.55} C140,${h*0.45} 220,${h*0.65} 340,${h*0.55} C460,${h*0.45} 520,${h*0.65} 600,${h*0.55} L600,${h} L0,${h} Z" fill="#0aa88f" fill-opacity=".55"/>
      ${[...Array(14)].map((_,i)=>`<circle cx="${40+ (i*41)%560}" cy="${h*0.42 + ((i*37)%40)}" r="${2+(i%3)}" fill="#123a6b" fill-opacity=".35"/>`).join("")}
      <g stroke="#fff" stroke-width="2.5" stroke-linecap="round" opacity=".8">
        <line x1="90" y1="14" x2="60" y2="${h*0.4}"/><line x1="140" y1="14" x2="120" y2="${h*0.4}"/><line x1="190" y1="14" x2="180" y2="${h*0.4}"/>
      </g>
    </svg>`;
  }
  if(key==="microplastics"){
    return `<svg viewBox="0 0 600 ${h}" preserveAspectRatio="xMidYMid slice" style="width:100%;height:100%;display:block;">
      ${bg}
      <path d="M0,${h*0.6} C100,${h*0.5} 220,${h*0.72} 320,${h*0.6} C420,${h*0.48} 520,${h*0.72} 600,${h*0.6} L600,${h} L0,${h} Z" fill="#8fd3d9"/>
      ${[[80,h*0.3,6],[150,h*0.22,4],[260,h*0.34,5],[350,h*0.2,4],[430,h*0.3,6],[500,h*0.22,4]].map(([x,y,s])=>`<rect x="${x}" y="${y}" width="${s}" height="${s}" fill="#e6553a" fill-opacity=".8" transform="rotate(${(x*3)%40} ${x} ${y})"/>`).join("")}
      <circle cx="470" cy="${h*0.32}" r="34" fill="none" stroke="#0b2545" stroke-width="4"/>
      <line x1="493" y1="${h*0.32+23}" x2="518" y2="${h*0.32+46}" stroke="#0b2545" stroke-width="6" stroke-linecap="round"/>
    </svg>`;
  }
  if(key==="score"){
    const cx=300, cy=h*0.82, r=150;
    const arc = (a0,a1,color)=>{
      const p0=[cx+r*Math.cos(a0), cy+r*Math.sin(a0)], p1=[cx+r*Math.cos(a1), cy+r*Math.sin(a1)];
      return `<path d="M${p0[0].toFixed(1)},${p0[1].toFixed(1)} A${r},${r} 0 0 1 ${p1[0].toFixed(1)},${p1[1].toFixed(1)}" fill="none" stroke="${color}" stroke-width="22" stroke-linecap="round"/>`;
    };
    const PI = Math.PI;
    return `<svg viewBox="0 0 600 ${h}" preserveAspectRatio="xMidYMid slice" style="width:100%;height:100%;display:block;">
      ${bg}
      ${arc(PI, PI+0.45*PI, "#e6553a")}
      ${arc(PI+0.45*PI, PI+0.75*PI, "#f2b134")}
      ${arc(PI+0.75*PI, 2*PI, "#12b886")}
      <line x1="${cx}" y1="${cy}" x2="${(cx+r*0.75*Math.cos(PI+0.62*PI)).toFixed(1)}" y2="${(cy+r*0.75*Math.sin(PI+0.62*PI)).toFixed(1)}" stroke="#0b2545" stroke-width="6" stroke-linecap="round"/>
      <circle cx="${cx}" cy="${cy}" r="9" fill="#0b2545"/>
    </svg>`;
  }
  // report
  return `<svg viewBox="0 0 600 ${h}" preserveAspectRatio="xMidYMid slice" style="width:100%;height:100%;display:block;">
    ${bg}
    <g stroke="var(--line)" stroke-width="1">
      ${[...Array(6)].map((_,i)=>`<line x1="${i*100}" y1="0" x2="${i*100}" y2="${h}"/>`).join("")}
      ${[...Array(4)].map((_,i)=>`<line x1="0" y1="${i*(h/3)}" x2="600" y2="${i*(h/3)}"/>`).join("")}
    </g>
    <path d="M300,${h*0.22} C330,${h*0.22} 352,${h*0.42} 352,${h*0.6} C352,${h*0.8} 300,${h*0.98} 300,${h*0.98} C300,${h*0.98} 248,${h*0.8} 248,${h*0.6} C248,${h*0.42} 270,${h*0.22} 300,${h*0.22} Z" fill="#e6553a"/>
    <circle cx="300" cy="${h*0.5}" r="16" fill="#fff"/>
    <rect x="390" y="${h*0.28}" width="86" height="60" rx="8" fill="#0b2545"/>
    <circle cx="433" cy="${h*0.28+30}" r="16" fill="#5be0c5"/>
  </svg>`;
}

let openLearnIndex = null;

function attachLearnEvents(){
  document.querySelectorAll("[data-learn-index]").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      openLearnIndex = parseInt(btn.dataset.learnIndex, 10);
      renderLearnModal();
    });
  });
}

function renderLearnModal(){
  let modal = document.getElementById("learnModal");
  if(!modal){
    modal = document.createElement("div");
    modal.id = "learnModal";
    modal.hidden = true;
    document.body.appendChild(modal);
  }
  if(openLearnIndex===null){ modal.hidden = true; modal.innerHTML=""; return; }
  const t = LEARN_TOPICS[openLearnIndex];
  modal.hidden = false;
  modal.innerHTML = `
    <div class="learn-modal-backdrop" id="learnModalBackdrop">
      <div class="learn-modal" role="dialog" aria-modal="true" aria-label="${t.title}">
        <div class="learn-modal-art">${learnArtSVG(t.art, false)}</div>
        <div class="learn-modal-inner">
          <div class="learn-modal-head">
            <span class="learn-tag">${t.tag}</span>
            <button type="button" class="learn-modal-close" id="learnModalClose" aria-label="Close">${ICONS.close}</button>
          </div>
          <h2>${t.title}</h2>
          <div class="learn-modal-meta">${t.read} read · Open-source water-quality science, summarised in plain language</div>
          <div class="learn-modal-body">
            ${t.full.map(sec=> sec.list
              ? `<h4>${sec.h}</h4><ul>${sec.list.map(li=>`<li>${li}</li>`).join("")}</ul>`
              : `<h4>${sec.h}</h4><p>${sec.p}</p>`
            ).join("")}
          </div>
        </div>
      </div>
    </div>`;
  document.getElementById("learnModalClose").onclick = ()=>{ openLearnIndex=null; renderLearnModal(); };
  document.getElementById("learnModalBackdrop").addEventListener("click", (e)=>{
    if(e.target.id==="learnModalBackdrop"){ openLearnIndex=null; renderLearnModal(); }
  });
}

/* ============================================================
   AI SCAN PAGE
============================================================ */
function renderScan(){
  const hasImg = !!scanState.img;
  const r = scanState.result;
  return `
    <div class="page page-narrow">
      <div class="title-row">${ICONS.scan}<h1>AI Water Scan</h1></div>
      <div class="page-sub" style="margin-bottom:24px;">Upload or pick a sample photo — our vision model estimates clarity, turbidity and likely contaminants in seconds.</div>
      <div class="scan-grid">
        <div>
          <div class="dropzone ${hasImg?'has-img':''}" id="dropzone">
            ${hasImg
              ? `<img src="${scanState.img}" alt="water sample"/>`
              : `<div class="dz-icon">${ICONS.upload}</div><div style="font-weight:700;font-size:13.5px;">Drop a photo or click to upload</div><div style="font-size:11.5px;color:var(--ink-faint);margin-top:4px;">JPG or PNG, analysed instantly in-browser</div>`
            }
          </div>
          <input type="file" id="fileInput" accept="image/*" hidden />
          <div class="sample-row">
            ${SCAN_PRESETS.map(p=>`<button type="button" class="sample-swatch" data-preset="${p.key}" style="background:${p.grad};${scanState.presetKey===p.key?'border-color:var(--teal);':''}"><span>${p.label.split(' ')[0]}</span></button>`).join("")}
          </div>
          <button class="scan-analyze" id="analyzeBtn" ${(!hasImg||scanState.analyzing)?'disabled':''}>${scanState.analyzing?'Analysing…':'Run AI Analysis'}</button>
          ${scanState.analyzing ? `
          <div class="scan-progress">
            <div class="row"><span id="scanStepLabel">Analysing pixel colorimetry…</span><span>${scanState.progress}%</span></div>
            <div class="scan-bar"><div class="scan-bar-fill" style="width:${scanState.progress}%"></div></div>
          </div>` : ``}
        </div>
        <div class="scan-result">
          ${r ? `
            <div class="scan-score-row">
              <div class="scan-score-ring" style="background:${riskBg(r.risk)};color:${riskFg(r.risk)}">${r.clarity}</div>
              <div>
                <div style="font-weight:800;font-size:15px;">Clarity Index</div>
                <div style="font-size:12px;color:var(--ink-soft);margin-top:2px;">${riskLabel(r.risk)} — turbidity: ${r.turbidity}</div>
              </div>
            </div>
            <div class="scan-tags">
              ${r.contaminants.map(c=>`<span class="scan-tag" style="background:${riskBg(r.risk)};color:${riskFg(r.risk)}">${c}</span>`).join("")}
            </div>
            <div style="margin-top:18px;">
              <div class="scan-metric"><span>Estimated pH range</span><strong>${r.risk==='high'?'5.6 – 6.3':(r.risk==='med'?'6.4 – 7.0':'7.0 – 7.6')}</strong></div>
              <div class="scan-metric"><span>Microplastic likelihood</span><strong>${r.risk==='high'?'High':(r.risk==='med'?'Moderate':'Low')}</strong></div>
              <div class="scan-metric"><span>Recommended action</span><strong>${r.risk==='high'?'Report immediately':(r.risk==='med'?'Monitor / re-scan':'No action needed')}</strong></div>
            </div>
            ${r.risk!=='low' ? `<button class="submit-btn" style="margin-top:16px;" id="scanReportBtn">File a report from this scan ${ICONS.send}</button>` : ``}
          ` : `<div class="scan-empty">${ICONS.flask}<div style="margin-top:10px;">Upload or pick a sample above, then run analysis to see results here.</div></div>`}
        </div>
      </div>
    </div>
  `;
}
function riskBg(r){ return r==='high' ? 'var(--high-bg)' : r==='med' ? 'var(--med-bg)' : 'var(--low-bg)'; }
function riskFg(r){ return r==='high' ? 'var(--high-fg)' : r==='med' ? 'var(--med-fg)' : 'var(--low-fg)'; }
function riskLabel(r){ return r==='high' ? 'High Risk' : r==='med' ? 'Moderate' : 'Good'; }

function attachScanEvents(){
  const dz = document.getElementById("dropzone");
  const fileInput = document.getElementById("fileInput");
  if(dz) dz.onclick = ()=> fileInput && fileInput.click();
  if(fileInput) fileInput.onchange = (e)=>{
    const file = e.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = (ev)=>{
      scanState = {img:ev.target.result, analyzing:false, progress:0, result:null, presetKey:null};
      render();
    };
    reader.readAsDataURL(file);
  };
  document.querySelectorAll(".sample-swatch").forEach(btn=>{
    btn.onclick = ()=>{
      const preset = SCAN_PRESETS.find(p=>p.key===btn.dataset.preset);
      scanState = {img:`data:image/svg+xml;utf8,${encodeURIComponent(`<svg xmlns='http://www.w3.org/2000/svg' width='400' height='240'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'>${preset.key==='clear'?"<stop offset='0' stop-color='%238fd3d9'/><stop offset='1' stop-color='%233aa8c1'/>":preset.key==='murky'?"<stop offset='0' stop-color='%23c9a15c'/><stop offset='1' stop-color='%238a6a3a'/>":"<stop offset='0' stop-color='%235a5a3c'/><stop offset='1' stop-color='%2322261b'/>"}</linearGradient></defs><rect width='400' height='240' fill='url(%23g)'/></svg>`)}`, analyzing:false, progress:0, result:null, presetKey:preset.key};
      render();
    };
  });
  const analyzeBtn = document.getElementById("analyzeBtn");
  if(analyzeBtn) analyzeBtn.onclick = ()=> runScanAnalysis();
  const scanReportBtn = document.getElementById("scanReportBtn");
  if(scanReportBtn) scanReportBtn.onclick = ()=> navigate("report");
}
const SCAN_STEPS = ["Analysing pixel colorimetry…","Estimating turbidity from light scatter…","Scanning for microplastic signatures…","Cross-referencing nearby station baselines…","Finalising report…"];
function runScanAnalysis(){
  scanState.analyzing = true;
  scanState.progress = 0;
  render();
  let step = 0;
  const timer = setInterval(()=>{
    step++;
    scanState.progress = Math.min(100, Math.round((step/SCAN_STEPS.length)*100));
    const label = document.getElementById("scanStepLabel");
    if(label) label.textContent = SCAN_STEPS[Math.min(step,SCAN_STEPS.length-1)];
    const fill = document.querySelector(".scan-bar-fill");
    if(fill) fill.style.width = scanState.progress+"%";
    const pct = document.querySelector(".scan-progress .row span:last-child");
    if(pct) pct.textContent = scanState.progress+"%";
    if(step>=SCAN_STEPS.length){
      clearInterval(timer);
      let preset = SCAN_PRESETS.find(p=>p.key===scanState.presetKey);
      if(!preset){
        // deterministic mock result from image data length
        const seedVal = (scanState.img||"").length % SCAN_PRESETS.length;
        preset = SCAN_PRESETS[seedVal];
      }
      scanState.analyzing = false;
      scanState.result = preset;
      render();
    }
  }, 420);
}

/* ============================================================
   COMPARE STATIONS PAGE
============================================================ */
function renderCompare(){
  const a = MONITOR_POINTS.find(p=>p.code===compareCodes[0]);
  const b = MONITOR_POINTS.find(p=>p.code===compareCodes[1]);
  const cardFor = (p)=>`
    <div class="compare-card">
      <div class="code">${p.code}</div>
      <h3>${p.name}</h3>
      <div class="compare-metric-row"><span>Score</span><strong style="color:${STATUS_COLOR[p.status]}">${p.score}</strong></div>
      <div class="compare-metric-row"><span>Status</span><strong>${STATUS_LABEL[p.status]}</strong></div>
      <div class="compare-metric-row"><span>14-day trend</span><strong>${stationHistory(p).slope>=0?'↑ improving':'↓ declining'}</strong></div>
      <div class="compare-metric-row"><span>3-day forecast</span><strong>${stationHistory(p).forecast.join(" → ")}</strong></div>
    </div>`;
  return `
    <div class="page">
      <div class="title-row">${ICONS.trend}<h1>Compare Stations</h1></div>
      <div class="page-sub" style="margin-bottom:24px;">Put any two monitoring stations side by side.</div>
      <div class="compare-pickers">
        <select id="compareA">${MONITOR_POINTS.map(p=>`<option value="${p.code}" ${p.code===compareCodes[0]?'selected':''}>${p.name}</option>`).join("")}</select>
        <select id="compareB">${MONITOR_POINTS.map(p=>`<option value="${p.code}" ${p.code===compareCodes[1]?'selected':''}>${p.name}</option>`).join("")}</select>
      </div>
      <div class="compare-cards">${cardFor(a)}${cardFor(b)}</div>
      <div class="compare-canvas-wrap">${compareChartSVG(a,b)}</div>
      ${compareSummaryHTML(a,b)}
    </div>
  `;
}

function compareSummaryHTML(a,b){
  const ha = stationHistory(a), hb = stationHistory(b);
  const diff = Math.abs(a.score - b.score);
  const leader = a.score===b.score ? null : (a.score>b.score ? a : b);
  const leaderRow = leader
    ? `<strong style="color:${STATUS_COLOR[leader.status]}">${leader.name}</strong> is currently ahead by <strong>${diff}</strong> point${diff===1?'':'s'}.`
    : `Both stations are tied at <strong>${a.score}</strong>.`;
  const bothImproving = ha.slope>=0 && hb.slope>=0;
  const bothDeclining = ha.slope<0 && hb.slope<0;
  const trendNote = bothImproving ? "Both areas are trending upward over the last 6 days."
    : bothDeclining ? "Both areas are trending downward over the last 6 days — worth flagging for follow-up."
    : `${ha.slope>=hb.slope ? a.name : b.name} has the stronger recent trend.`;
  const closingGap = (Math.abs((a.score+ha.forecast[2])-( b.score+hb.forecast[2])) < diff);
  const gapNote = a.score===b.score ? "" : (closingGap ? "The gap between the two is projected to narrow over the next 3 days."
    : "The gap between the two is projected to widen over the next 3 days.");
  return `
    <div class="panel compare-summary">
      <div class="panel-head"><h2>Comparison Summary</h2></div>
      <div class="compare-summary-body">
        <div class="compare-summary-row"><span class="cs-label">Score gap</span><span class="cs-val">${leaderRow}</span></div>
        <div class="compare-summary-row"><span class="cs-label">Status</span><span class="cs-val">${a.name} is <strong style="color:${STATUS_COLOR[a.status]}">${STATUS_LABEL[a.status]}</strong>, ${b.name} is <strong style="color:${STATUS_COLOR[b.status]}">${STATUS_LABEL[b.status]}</strong>.</span></div>
        <div class="compare-summary-row"><span class="cs-label">6-day trend</span><span class="cs-val">${trendNote}</span></div>
        ${gapNote ? `<div class="compare-summary-row"><span class="cs-label">3-day outlook</span><span class="cs-val">${gapNote}</span></div>` : ``}
        <div class="compare-summary-row"><span class="cs-label">Forecast (+3d)</span><span class="cs-val">${a.name}: <strong>${ha.forecast[2]}</strong> &nbsp;·&nbsp; ${b.name}: <strong>${hb.forecast[2]}</strong></span></div>
      </div>
    </div>`;
}
function attachCompareEvents(){
  const selA = document.getElementById("compareA");
  const selB = document.getElementById("compareB");
  if(selA) selA.onchange = ()=>{ compareCodes[0]=selA.value; render(); };
  if(selB) selB.onchange = ()=>{ compareCodes[1]=selB.value; render(); };
}

/* ============================================================
   IMPACT / ABOUT PAGE
============================================================ */
function renderImpact(){
  return `
    <div class="page">
      <div class="impact-hero">
        <h1>Built for impact, not just a demo.</h1>
        <p>Poseidon X pairs low-cost IoT sensor buoys with citizen reporting and on-device AI, turning every coastline, lake and river into a monitored, accountable system.</p>
      </div>
      <div class="title-row" style="margin-bottom:2px;">${ICONS.shield}<h1 style="font-size:18px;">UN Sustainable Development Goals</h1></div>
      <div class="page-sub">How this project moves the needle on global goals.</div>
      <div class="sdg-grid">
        ${SDGS.map(s=>`
          <div class="sdg-card" style="background:${s.color}">
            <div class="num">${s.num}</div>
            <div class="name">${s.name}</div>
            <div class="desc">${s.desc}</div>
          </div>`).join("")}
      </div>
      <div class="title-row" style="margin-bottom:2px;">${ICONS.cpu}<h1 style="font-size:18px;">The Hardware</h1></div>
      <div class="page-sub">What's inside a Poseidon monitoring buoy.</div>
      <div class="hw-grid">
        ${HARDWARE.map(h=>`
          <div class="hw-card">
            <div class="hwi">${ICONS[h.icon]}</div>
            <h4>${h.title}</h4>
            <p>${h.body}</p>
          </div>`).join("")}
      </div>
      <div class="title-row" style="margin:32px 0 2px;">${ICONS.trophy}<h1 style="font-size:18px;">Team</h1></div>
      <div class="team-row">
        ${TEAM.map(t=>`
          <div class="team-pill"><span class="team-avatar">${t.name.split(" ").map(n=>n[0]).join("")}</span> ${t.name} <span style="color:var(--ink-faint);font-weight:600;">· ${t.role}</span></div>`).join("")}
      </div>
    </div>
  `;
}

function renderReport(submitted, data){
  if(submitted){
    return `
      <div class="page page-xnarrow">
        <div class="success">
          <div class="success-icon">${ICONS.shield}</div>
          <h1>Report received</h1>
          <p>Thanks — your anonymous report for <strong>${data.name}</strong> has been logged and queued for review.</p>
          <button class="btn btn-dark" style="margin-top:20px;" id="reportAgain">File another report</button>
        </div>
      </div>
    `;
  }
  return `
    <div class="page page-xnarrow">
      <div class="report-head">
        <h1>Report Water Pollution</h1>
        <div class="kicker">TRACK. DETECT. PROTECT.</div>
        <p>Help protect our waters by reporting pollution incidents anonymously. Your reports make a difference.</p>
      </div>
      <form class="form-card" id="reportForm">
        <div class="form-section">
          <h2>Location Information</h2>
          <div class="field">
            <label>Location Name *</label>
            <input type="text" id="f-name" placeholder="e.g., Marina Beach, Chennai" required />
          </div>
          <div class="row2">
            <div class="field">
              <label>Latitude *</label>
              <input type="text" id="f-lat" placeholder="13.0499" required />
            </div>
            <div class="field">
              <label>Longitude *</label>
              <input type="text" id="f-lng" placeholder="80.2824" required />
            </div>
          </div>
          <div class="field-row-btns">
            <button type="button" class="mini-btn" id="useLocationBtn">${ICONS.location} Use my location</button>
            <button type="button" class="mini-btn ${reportExtras.recording?'active':''}" id="voiceBtn">${ICONS.mic} ${reportExtras.recording?'Recording…':'Add voice note'}</button>
          </div>
          <div class="hint">Provide a descriptive location name and its coordinates.</div>
        </div>

        <div class="form-section">
          <label style="font-size:12.5px;font-weight:600;color:var(--ink-soft);">Severity</label>
          <div class="sev-row" id="sevRow">
            ${["Low","Medium","High"].map(s=>`<button type="button" class="sev-btn ${s===reportExtras.severity?'active':''}" data-sev="${s}">${s}</button>`).join("")}
          </div>
        </div>

        <div class="form-section field">
          <label>What did you observe?</label>
          <textarea id="f-desc" rows="4" placeholder="Describe colour, odour, dead fish, foam, discharge pipes, etc.">${reportExtras.desc||""}</textarea>
        </div>

        <div class="form-section">
          <label style="font-size:12.5px;font-weight:600;color:var(--ink-soft);">Photo evidence (optional)</label>
          <div class="field-row-btns" style="margin-top:8px;">
            <button type="button" class="mini-btn" id="photoBtn">${ICONS.upload} ${reportExtras.photo?'Replace photo':'Add a photo'}</button>
          </div>
          <input type="file" id="photoInput" accept="image/*" hidden />
          ${reportExtras.photo ? `<div class="photo-preview"><img src="${reportExtras.photo}" alt="evidence"/></div>` : ``}
        </div>

        <button type="submit" class="submit-btn">Submit Report ${ICONS.send}</button>
      </form>
    </div>
  `;
}

let reportState = { submitted:false, data:{} };
let reportExtras = { severity:"Medium", photo:null, recording:false, desc:"" };

function attachReportEvents(){
  if(reportState.submitted){
    const again = document.getElementById("reportAgain");
    if(again) again.onclick = ()=>{ reportState = {submitted:false, data:{}}; reportExtras = {severity:"Medium", photo:null, recording:false, desc:""}; render(); };
    return;
  }
  const form = document.getElementById("reportForm");
  if(!form) return;
  const sevRow = document.getElementById("sevRow");
  sevRow.querySelectorAll(".sev-btn").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      sevRow.querySelectorAll(".sev-btn").forEach(b=>b.classList.remove("active"));
      btn.classList.add("active");
      reportExtras.severity = btn.dataset.sev;
    });
  });
  const descEl = document.getElementById("f-desc");
  if(descEl) descEl.addEventListener("input", ()=>{ reportExtras.desc = descEl.value; });

  const locBtn = document.getElementById("useLocationBtn");
  if(locBtn) locBtn.addEventListener("click", ()=>{
    if(!navigator.geolocation){ locBtn.textContent = "Location unavailable"; return; }
    locBtn.innerHTML = "Locating…";
    navigator.geolocation.getCurrentPosition((pos)=>{
      document.getElementById("f-lat").value = pos.coords.latitude.toFixed(4);
      document.getElementById("f-lng").value = pos.coords.longitude.toFixed(4);
      locBtn.innerHTML = `${ICONS.location} Location added`;
    }, ()=>{ locBtn.innerHTML = `${ICONS.location} Permission denied`; });
  });

  const voiceBtn = document.getElementById("voiceBtn");
  if(voiceBtn) voiceBtn.addEventListener("click", ()=>{
    reportExtras.recording = !reportExtras.recording;
    render();
  });

  const photoBtn = document.getElementById("photoBtn");
  const photoInput = document.getElementById("photoInput");
  if(photoBtn) photoBtn.addEventListener("click", ()=> photoInput && photoInput.click());
  if(photoInput) photoInput.addEventListener("change", (e)=>{
    const file = e.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = (ev)=>{ reportExtras.photo = ev.target.result; render(); };
    reader.readAsDataURL(file);
  });

  form.addEventListener("submit", async (e)=>{
    e.preventDefault();
    const name = document.getElementById("f-name").value.trim();
    const lat = document.getElementById("f-lat").value.trim();
    const lng = document.getElementById("f-lng").value.trim();
    if(!name || !lat || !lng) return;

    const submitBtn = form.querySelector(".submit-btn");
    if(submitBtn){ submitBtn.disabled = true; submitBtn.textContent = "Submitting…"; }

    try{
      await apiFetch("/reports", {
        method:"POST",
        body: JSON.stringify({
          locationName: name,
          lat: Number(lat),
          lng: Number(lng),
          severity: reportExtras.severity,
          description: reportExtras.desc || null,
          photoDataUrl: reportExtras.photo || null,
        }),
      });
      reportState = { submitted:true, data:{name, lat, lng} };
    }catch(err){
      alert("Couldn't submit your report: " + err.message + "\nMake sure the API server is running.");
      if(submitBtn){ submitBtn.disabled = false; submitBtn.innerHTML = `Submit Report ${ICONS.send}`; }
      return;
    }
    render();
  });
}

/* ============================================================
   MAIN RENDER
============================================================ */
function render(){
  buildNav();
  if(leafletMapInstance){ leafletMapInstance.remove(); leafletMapInstance = null; }
  const app = document.getElementById("app");
  if(currentPage==="home") app.innerHTML = renderHome();
  else if(currentPage==="dashboard") { app.innerHTML = renderDashboard(); attachMapEvents(); attachDashboardEvents(); }
  else if(currentPage==="scan") { app.innerHTML = renderScan(); attachScanEvents(); }
  else if(currentPage==="compare") { app.innerHTML = renderCompare(); attachCompareEvents(); }
  else if(currentPage==="leaderboard") app.innerHTML = renderLeaderboard();
  else if(currentPage==="learn") { app.innerHTML = renderLearn(); attachLearnEvents(); }
  else if(currentPage==="impact") app.innerHTML = renderImpact();
  else if(currentPage==="report") { app.innerHTML = renderReport(reportState.submitted, reportState.data); attachReportEvents(); }

  // wire up any data-nav buttons inside rendered content
  app.querySelectorAll("[data-nav]").forEach(el=>{
    el.addEventListener("click", ()=> navigate(el.dataset.nav));
  });
  renderNotifPop();
  renderBotPanel();
  renderLearnModal();
}

/* ============================================================
   THEME TOGGLE
============================================================ */
document.getElementById("themeBtn").onclick = ()=>{
  darkMode = !darkMode;
  document.documentElement.setAttribute("data-theme", darkMode ? "dark" : "light");
  document.getElementById("themeIcon").innerHTML = darkMode
    ? '<circle cx="12" cy="12" r="4"/><path d="M12 3v1M12 20v1M4.2 4.2l.7.7M19.1 19.1l.7.7M3 12h1M20 12h1M4.2 19.8l.7-.7M19.1 4.9l.7-.7"/>'
    : '<path d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8Z"/>';
};

/* ============================================================
   NOTIFICATIONS
============================================================ */
function renderNotifPop(){
  const pop = document.getElementById("notifPop");
  const dot = document.getElementById("notifDot");
  if(dot) dot.style.display = notifOpen ? "none" : "block";
  if(!notifOpen){ pop.hidden = true; pop.innerHTML=""; return; }
  pop.hidden = false;
  pop.innerHTML = `
    <div class="notif-pop">
      <div class="notif-pop-head">Smart Alerts <span>${ALERTS.length} active</span></div>
      ${ALERTS.slice(0,4).map(a=>`
        <div class="notif-item">
          <div class="t">${ICONS[a.icon]} ${a.title} <span class="badge badge-${a.level}" style="margin-left:auto;">${a.level}</span></div>
          <div class="b">${a.body}</div>
          <div class="m">${a.code} · ${a.hours}h ago</div>
        </div>`).join("")}
      <div class="notif-foot"><button data-nav="dashboard" id="notifSeeAll">Open dashboard</button></div>
    </div>`;
  const seeAll = document.getElementById("notifSeeAll");
  if(seeAll) seeAll.addEventListener("click", ()=>{ notifOpen=false; navigate("dashboard"); });
}
document.getElementById("notifBtn").onclick = (e)=>{
  e.stopPropagation();
  notifOpen = !notifOpen;
  botOpen = false;
  renderNotifPop();
  renderBotPanel();
};
document.addEventListener("click", (e)=>{
  if(notifOpen && !e.target.closest(".notif-pop") && !e.target.closest("#notifBtn")){ notifOpen=false; renderNotifPop(); }
});

/* ============================================================
   AQUABOT ASSISTANT
============================================================ */
const BOT_CHIPS = ["What's a good score?", "Any alerts near me?", "How do I report pollution?", "What is turbidity?"];
function botReply(q){
  const s = q.toLowerCase();
  if(s.includes("score")) return "Scores run 0–100: 70+ is Good, 45–69 is Moderate, below 45 is High Risk. It blends pH, turbidity, TDS, temperature and dissolved oxygen.";
  if(s.includes("alert") || s.includes("near")) return `There are currently ${ALERTS.length} active alerts, ${ALERTS.filter(a=>a.level==='HIGH').length} of them HIGH severity. Check the Dashboard's Smart Alerts panel for details.`;
  if(s.includes("report")) return "Go to the Report page, drop a pin (or use 'Use my location'), pick a severity, add a photo if you can, and submit — it's anonymous.";
  if(s.includes("turbid")) return "Turbidity measures how cloudy water is from suspended particles — a fast early-warning signal for runoff or discharge. See Learn → 'What is turbidity, really?'.";
  if(s.includes("microplastic")) return "Our AI Scan and buoy sensors flag microplastic density using laser-scatter + image analysis. Try the AI Scan page on a sample photo!";
  if(s.includes("forecast") || s.includes("predict")) return "The Dashboard's Trend & Forecast panel projects each station's score 3 days out using its recent 6-day trend.";
  if(s.includes("hi") || s.includes("hello") || s.includes("hey")) return "Hey! I can help with scores, alerts, reporting, or reading the dashboard. What's up?";
  return "Good question — I don't have a canned answer for that yet, but the Learn page covers most water-quality basics in plain language.";
}
function renderBotPanel(){
  const panel = document.getElementById("botPanel");
  if(!botOpen){ panel.hidden = true; panel.innerHTML=""; return; }
  panel.hidden = false;
  panel.innerHTML = `
    <div class="bot-panel">
      <div class="bot-head">
        <div class="bot-head-name"><span class="bot-status"></span> AquaBot</div>
        <button class="bot-close" id="botCloseBtn">${ICONS.close}</button>
      </div>
      <div class="bot-msgs" id="botMsgs">
        ${botMessages.map(m=>`<div class="bot-msg ${m.who}">${m.text}</div>`).join("")}
      </div>
      <div class="bot-suggest">${BOT_CHIPS.map(c=>`<button class="bot-chip" data-chip="${c}">${c}</button>`).join("")}</div>
      <div class="bot-input-row">
        <input type="text" id="botInput" placeholder="Ask AquaBot..." />
        <button class="bot-send" id="botSendBtn">${ICONS.send}</button>
      </div>
    </div>`;
  const msgsEl = document.getElementById("botMsgs");
  if(msgsEl) msgsEl.scrollTop = msgsEl.scrollHeight;
  document.getElementById("botCloseBtn").onclick = ()=>{ botOpen=false; renderBotPanel(); };
  document.querySelectorAll(".bot-chip").forEach(chip=>{
    chip.onclick = ()=> sendBotMessage(chip.dataset.chip);
  });
  document.getElementById("botSendBtn").onclick = ()=>{
    const inp = document.getElementById("botInput");
    if(inp.value.trim()) sendBotMessage(inp.value.trim());
  };
  document.getElementById("botInput").addEventListener("keydown",(e)=>{
    if(e.key==="Enter" && e.target.value.trim()) sendBotMessage(e.target.value.trim());
  });
}
function sendBotMessage(text){
  botMessages.push({who:"user", text});
  botMessages.push({who:"bot", text: botReply(text)});
  renderBotPanel();
}
document.getElementById("botFab").onclick = (e)=>{
  e.stopPropagation();
  botOpen = !botOpen;
  notifOpen = false;
  renderBotPanel();
  renderNotifPop();
};

render();

/* ============================================================
   INITIAL LOAD + LIVE DATA POLLING
   Stations, alerts and their live drift now live server-side
   (server/src/liveTick.js runs the same jitter logic against Postgres
   every 6s). Every connected browser polls GET /api/dashboard and
   GET /api/leaderboard and just reflects what the server says —
   nothing here invents data client-side anymore.
============================================================ */
function flashEl(el){
  if(!el) return;
  el.classList.add("flash");
  setTimeout(()=>el.classList.remove("flash"), 700);
}

function replaceArrayContents(arr, next){
  arr.splice(0, arr.length, ...next);
}

async function loadInitialData(){
  try{
    const [dash, board] = await Promise.all([
      apiFetch("/dashboard"),
      apiFetch("/leaderboard"),
    ]);
    replaceArrayContents(MONITOR_POINTS, dash.stations);
    replaceArrayContents(ALERTS, dash.alerts);
    replaceArrayContents(LEADERBOARD, board);
    render();
  }catch(e){
    console.warn("Could not reach the Poseidon X API — showing seed data until it's back.", e.message);
  }
}

async function pollDashboard(){
  try{
    const dash = await apiFetch("/dashboard");
    replaceArrayContents(MONITOR_POINTS, dash.stations);
    replaceArrayContents(ALERTS, dash.alerts);

    if(currentPage!=="dashboard") return;

    const avgEl = document.getElementById("avgScoreVal");
    if(avgEl){ avgEl.textContent = dash.summary.avgScore; flashEl(avgEl); }

    const poorEl = document.getElementById("zonesAttentionVal");
    if(poorEl){ poorEl.textContent = dash.summary.zonesNeedingAttention; flashEl(poorEl); }

    const alertsEl = document.getElementById("activeAlertsVal");
    if(alertsEl){ alertsEl.textContent = dash.summary.activeAlerts; flashEl(alertsEl); }

    const alertsSub = document.getElementById("activeAlertsSub");
    if(alertsSub) alertsSub.textContent = "Updated just now";

    const listEl = document.getElementById("smartAlertsList");
    if(listEl){
      listEl.innerHTML = ALERTS.map(a=>alertItemHTML(a)).join("");
      flashEl(listEl);
    }

    const freshEl = document.getElementById("freshTick");
    if(freshEl) freshEl.textContent = "Updated just now";
  }catch(e){
    console.warn("Dashboard poll failed:", e.message);
  }
}

loadInitialData();
setInterval(pollDashboard, 6000);
