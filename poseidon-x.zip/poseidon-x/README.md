# Poseidon X — full-stack build

Water-quality monitoring dashboard: citizen pollution reporting, live station
scores, smart alerts, a leaderboard, and an AI-scan mock. This version splits
the original single HTML file into a real client + API + database.

```
poseidon-x/
├── index.html          Frontend entry point
├── css/style.css        Frontend styles
├── js/app.js             Frontend logic (fetches from the API below)
├── docker-compose.yml    One command to run Postgres + the API together
└── server/               Node/Express + PostgreSQL backend
    ├── db/schema.sql      Table definitions
    ├── db/seed.sql        Seed data (stations, alerts, leaderboard)
    ├── scripts/seed-history.js   Seeds 14-day score history for charts
    └── src/               Express app, routes, live-data background job
```

## What's real now vs. the original file

The original `poseidon-x.html` was 100% client-side — all data (stations,
alerts, leaderboard) was hardcoded in JS, and the "live" updates were just
`Math.random()` jittering numbers in memory with nothing persisted.

This version:
- Stores stations, alerts, reports, leaderboard, and score history in **Postgres**.
- Runs the "live" score/alert drift **on the server** (`server/src/liveTick.js`)
  every 6s, so every connected browser sees the same numbers, not its own
  fake simulation.
- **Report submissions are actually saved** — `POST /api/reports` writes to
  the `reports` table.
- The frontend polls `GET /api/dashboard` every 6s and renders whatever the
  server returns.

Things intentionally left as static frontend content (no DB needed): the
Learn articles, SDG/hardware/team info on the Impact page, and the AI Scan
page's mock analysis (it was never a real vision model — it's a canned
result picker, same as before).

## Run it

### Option A — Docker (recommended, fully production-style)

```bash
docker compose up --build
```
This starts Postgres, applies the schema + seed data, seeds 14-day history,
and starts the API on `http://localhost:4000`.

Then just open `index.html` in a browser (or serve the folder with any
static server, e.g. `npx serve .`).

### Option B — manual

```bash
# 1. Start Postgres yourself, then create a database, e.g.:
createdb poseidon_x

# 2. Configure the backend
cd server
cp .env.example .env
# edit .env with your DATABASE_URL

npm install
npm run db:schema   # creates tables
npm run db:seed      # seeds stations/alerts/leaderboard + history
npm start             # http://localhost:4000
```

Then open `index.html` (or serve `/` with any static file server) in
another terminal/tab. If your API isn't on `localhost:4000`, edit the
`window.POSEIDON_API_BASE` line near the bottom of `index.html`.

## API

| Method | Path                          | Purpose                                   |
|--------|-------------------------------|--------------------------------------------|
| GET    | `/api/health`                 | DB connectivity check                      |
| GET    | `/api/stations`               | All monitoring stations                    |
| GET    | `/api/stations/:code/history` | 14-day history + 3-day forecast            |
| GET    | `/api/alerts`                 | Active alerts                              |
| GET    | `/api/dashboard`              | Stations + alerts + summary (polled by UI) |
| GET    | `/api/leaderboard`            | Top contributors                           |
| POST   | `/api/reports`                | Submit an anonymous pollution report       |
| GET    | `/api/reports`                | List recent reports                        |

## Notes / next steps for a real deployment

- Add auth + rate limiting before exposing `POST /api/reports` publicly.
- Swap the base64 `photo_data_url` column for real object storage (S3, GCS, etc.) once report volume grows.
- Add a migrations tool (e.g. `node-pg-migrate`) instead of a single `schema.sql` once the schema needs to evolve post-launch.
