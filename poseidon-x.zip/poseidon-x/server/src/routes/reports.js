const express = require("express");
const db = require("../db");

const router = express.Router();

const VALID_SEVERITY = new Set(["Low", "Medium", "High"]);

// POST /api/reports — submit an anonymous pollution report
router.post("/", async (req, res, next) => {
  try {
    const { locationName, lat, lng, severity, description, photoDataUrl } = req.body || {};

    if (!locationName || typeof locationName !== "string" || !locationName.trim()) {
      return res.status(400).json({ error: "locationName is required" });
    }
    const latNum = Number(lat);
    const lngNum = Number(lng);
    if (Number.isNaN(latNum) || latNum < -90 || latNum > 90) {
      return res.status(400).json({ error: "lat must be a number between -90 and 90" });
    }
    if (Number.isNaN(lngNum) || lngNum < -180 || lngNum > 180) {
      return res.status(400).json({ error: "lng must be a number between -180 and 180" });
    }
    const sev = VALID_SEVERITY.has(severity) ? severity : "Medium";

    // Cap photo payload (base64 data URL) at ~5MB to avoid abuse via this open endpoint.
    if (photoDataUrl && photoDataUrl.length > 5 * 1024 * 1024) {
      return res.status(413).json({ error: "Photo is too large" });
    }

    const { rows } = await db.query(
      `INSERT INTO reports (location_name, lat, lng, severity, description, photo_data_url)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id, location_name, lat, lng, severity, status, created_at`,
      [locationName.trim(), latNum, lngNum, sev, description || null, photoDataUrl || null]
    );

    res.status(201).json(rows[0]);
  } catch (err) {
    next(err);
  }
});

// GET /api/reports — most recent reports (photo payload omitted to keep this light)
router.get("/", async (req, res, next) => {
  try {
    const limit = Math.min(Number(req.query.limit) || 50, 200);
    const { rows } = await db.query(
      `SELECT id, location_name, lat, lng, severity, description, status, created_at
       FROM reports ORDER BY created_at DESC LIMIT $1`,
      [limit]
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
