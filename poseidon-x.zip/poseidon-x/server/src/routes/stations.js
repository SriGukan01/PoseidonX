const express = require("express");
const db = require("../db");

const router = express.Router();

// GET /api/stations — all monitoring stations, current score/status
router.get("/", async (req, res, next) => {
  try {
    const { rows } = await db.query(
      `SELECT code, name, lat, lng, score, status, updated_at
       FROM stations ORDER BY name ASC`
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

// GET /api/stations/:code — single station
router.get("/:code", async (req, res, next) => {
  try {
    const { rows } = await db.query(
      `SELECT code, name, lat, lng, score, status, updated_at
       FROM stations WHERE code = $1`,
      [req.params.code]
    );
    if (!rows.length) return res.status(404).json({ error: "Station not found" });
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
});

// GET /api/stations/:code/history — 14-day score history + 3-day linear forecast,
// used by the Dashboard trend panel and the Compare page.
router.get("/:code/history", async (req, res, next) => {
  try {
    const { rows } = await db.query(
      `SELECT day_index, score FROM station_history
       WHERE station_code = $1 ORDER BY day_index ASC`,
      [req.params.code]
    );
    if (!rows.length) return res.status(404).json({ error: "No history for station" });

    const hist = rows.map((r) => r.score);

    // Simple linear regression over the last 6 points -> project 3 days out.
    const tail = hist.slice(-6);
    const n = tail.length;
    const xs = tail.map((_, i) => i);
    const xbar = xs.reduce((a, b) => a + b, 0) / n;
    const ybar = tail.reduce((a, b) => a + b, 0) / n;
    let num = 0;
    let den = 0;
    for (let i = 0; i < n; i++) {
      num += (xs[i] - xbar) * (tail[i] - ybar);
      den += (xs[i] - xbar) ** 2;
    }
    const slope = den === 0 ? 0 : num / den;

    const forecast = [];
    let last = hist[hist.length - 1];
    for (let i = 1; i <= 3; i++) {
      last = Math.max(5, Math.min(99, last + slope));
      forecast.push(Math.round(last));
    }

    res.json({ code: req.params.code, hist, forecast, slope });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
