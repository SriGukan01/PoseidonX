const express = require("express");
const db = require("../db");

const router = express.Router();

// GET /api/alerts — currently active alerts, most recent first
router.get("/", async (req, res, next) => {
  try {
    const { rows } = await db.query(
      `SELECT id, title, level, body, station_code AS code, hours_ago AS hours, duration, icon, created_at
       FROM alerts ORDER BY hours_ago ASC, created_at DESC`
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
