const express = require("express");
const db = require("../db");

const router = express.Router();

// GET /api/dashboard — stations + alerts + summary in one call.
// The frontend polls this every 6s so all connected clients see the same
// server-driven "live" data instead of each client faking its own drift.
router.get("/", async (req, res, next) => {
  try {
    const [stationsRes, alertsRes] = await Promise.all([
      db.query(`SELECT code, name, lat, lng, score, status, updated_at FROM stations ORDER BY name ASC`),
      db.query(
        `SELECT id, title, level, body, station_code AS code, hours_ago AS hours, duration, icon, created_at
         FROM alerts ORDER BY hours_ago ASC, created_at DESC`
      ),
    ]);

    const stations = stationsRes.rows;
    const alerts = alertsRes.rows;
    const avg = stations.length
      ? Math.round(stations.reduce((s, p) => s + p.score, 0) / stations.length)
      : 0;
    const poor = stations.filter((p) => p.status === "poor").length;

    res.json({
      stations,
      alerts,
      summary: { avgScore: avg, zonesNeedingAttention: poor, activeAlerts: alerts.length },
      updatedAt: new Date().toISOString(),
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
