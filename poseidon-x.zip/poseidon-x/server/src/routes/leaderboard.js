const express = require("express");
const db = require("../db");

const router = express.Router();

// GET /api/leaderboard — top contributors, ranked by points
router.get("/", async (req, res, next) => {
  try {
    const { rows } = await db.query(
      `SELECT name, region, points, reports,
              RANK() OVER (ORDER BY points DESC) AS rank
       FROM leaderboard ORDER BY points DESC`
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
