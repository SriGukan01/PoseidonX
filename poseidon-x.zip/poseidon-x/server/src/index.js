require("dotenv").config();
const express = require("express");
const cors = require("cors");

const db = require("./db");
const { startLiveTick } = require("./liveTick");

const stationsRouter = require("./routes/stations");
const alertsRouter = require("./routes/alerts");
const reportsRouter = require("./routes/reports");
const leaderboardRouter = require("./routes/leaderboard");
const dashboardRouter = require("./routes/dashboard");

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors({ origin: process.env.CORS_ORIGIN || "*" }));
// Higher limit than express' default so a base64 photo on a report can fit.
app.use(express.json({ limit: "6mb" }));

app.get("/api/health", async (req, res) => {
  try {
    await db.query("SELECT 1");
    res.json({ ok: true, db: "connected" });
  } catch (err) {
    res.status(503).json({ ok: false, db: "unreachable", error: err.message });
  }
});

app.use("/api/stations", stationsRouter);
app.use("/api/alerts", alertsRouter);
app.use("/api/reports", reportsRouter);
app.use("/api/leaderboard", leaderboardRouter);
app.use("/api/dashboard", dashboardRouter);

// 404 for unknown API routes
app.use("/api", (req, res) => res.status(404).json({ error: "Not found" }));

// Central error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

app.listen(PORT, () => {
  console.log(`Poseidon X API listening on http://localhost:${PORT}`);
  const stopTick = startLiveTick(6000);
  process.on("SIGTERM", stopTick);
  process.on("SIGINT", stopTick);
});
