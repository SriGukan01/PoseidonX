const { Pool } = require("pg");

// Either set DATABASE_URL, or the discrete PG* vars below. Both are supported
// so this works the same locally (docker-compose) and on most managed hosts
// (Render, Railway, RDS, etc.) that hand you a single connection string.
const pool = new Pool(
  process.env.DATABASE_URL
    ? {
        connectionString: process.env.DATABASE_URL,
        ssl: process.env.PGSSL === "true" ? { rejectUnauthorized: false } : false,
      }
    : {
        host: process.env.PGHOST || "localhost",
        port: Number(process.env.PGPORT || 5432),
        user: process.env.PGUSER || "postgres",
        password: process.env.PGPASSWORD || "postgres",
        database: process.env.PGDATABASE || "poseidon_x",
      }
);

pool.on("error", (err) => {
  // Idle client errors (e.g. connection dropped) shouldn't crash the process.
  console.error("Unexpected Postgres pool error", err);
});

module.exports = {
  query: (text, params) => pool.query(text, params),
  pool,
};
