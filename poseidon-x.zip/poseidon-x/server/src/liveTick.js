const db = require("./db");

// Mirrors the original frontend-only `tickLiveData()` mock, but now the drift
// happens once, in Postgres, so every connected browser polling /api/dashboard
// sees the same "live" numbers instead of each tab inventing its own.

function scoreToStatus(score) {
  return score >= 70 ? "good" : score >= 45 ? "fair" : "poor";
}

function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

async function driftStationScores() {
  const { rows: stations } = await db.query("SELECT code, score FROM stations");
  for (const s of stations) {
    const delta = randInt(-3, 3);
    const newScore = Math.max(4, Math.min(97, s.score + delta));
    await db.query(
      "UPDATE stations SET score = $1, status = $2, updated_at = now() WHERE code = $3",
      [newScore, scoreToStatus(newScore), s.code]
    );
  }
}

async function ageAlerts() {
  // ~60% of active alerts get an hour older each tick, same as the original mock.
  await db.query(
    `UPDATE alerts SET hours_ago = hours_ago + 1 WHERE random() < 0.6`
  );
}

async function resolveOldestAlertMaybe() {
  const { rows: countRows } = await db.query("SELECT COUNT(*)::int AS n FROM alerts");
  if (countRows[0].n > 3 && Math.random() < 0.18) {
    await db.query(
      `DELETE FROM alerts WHERE id = (SELECT id FROM alerts ORDER BY hours_ago DESC LIMIT 1)`
    );
  }
}

async function rotateInNewAlertMaybe() {
  const { rows: countRows } = await db.query("SELECT COUNT(*)::int AS n FROM alerts");
  if (countRows[0].n >= 7 || Math.random() >= 0.22) return;

  const { rows: pool } = await db.query("SELECT * FROM alert_pool");
  if (!pool.length) return;

  const candidate = pool[randInt(0, pool.length - 1)];
  const { rows: dupe } = await db.query(
    "SELECT 1 FROM alerts WHERE title = $1 AND station_code = $2",
    [candidate.title, candidate.station_code]
  );
  if (dupe.length) return;

  await db.query(
    `INSERT INTO alerts (title, level, body, station_code, hours_ago, duration, icon)
     VALUES ($1, $2, $3, $4, 0, $5, $6)`,
    [candidate.title, candidate.level, candidate.body, candidate.station_code, candidate.duration, candidate.icon]
  );
}

async function tick() {
  try {
    await driftStationScores();
    await ageAlerts();
    await resolveOldestAlertMaybe();
    await rotateInNewAlertMaybe();
  } catch (err) {
    console.error("liveTick error:", err.message);
  }
}

function startLiveTick(intervalMs = 6000) {
  const handle = setInterval(tick, intervalMs);
  return () => clearInterval(handle);
}

module.exports = { startLiveTick, tick };
