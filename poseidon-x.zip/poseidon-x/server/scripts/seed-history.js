// Generates the 14-day score history for every station and writes it to
// station_history. Uses the exact same Lehmer PRNG the original single-file
// prototype used client-side, so the trend/forecast charts look identical —
// the only thing that changed is *where* this data now lives (Postgres,
// computed once, shared by every client) instead of being recomputed
// per-browser on every render.
require("dotenv").config();
const db = require("../src/db");

function seeded(seed) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return function () {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function buildHistory(code, score) {
  const seedNum = code.split("").reduce((a, c) => a + c.charCodeAt(0), 0) + score;
  const rnd = seeded(seedNum);
  const days = 14;
  let val = score + (rnd() * 10 - 5);
  const hist = [];
  for (let i = days; i > 0; i--) {
    val += rnd() * 10 - 5;
    val = Math.max(8, Math.min(97, val));
    hist.push(Math.round(val));
  }
  hist[hist.length - 1] = score;
  return hist;
}

async function main() {
  const { rows: stations } = await db.query("SELECT code, score FROM stations");
  if (!stations.length) {
    console.error("No stations found — run db/seed.sql first.");
    process.exit(1);
  }

  for (const s of stations) {
    const hist = buildHistory(s.code, s.score);
    for (let dayIndex = 0; dayIndex < hist.length; dayIndex++) {
      await db.query(
        `INSERT INTO station_history (station_code, day_index, score)
         VALUES ($1, $2, $3)
         ON CONFLICT (station_code, day_index) DO UPDATE SET score = EXCLUDED.score`,
        [s.code, dayIndex, hist[dayIndex]]
      );
    }
    console.log(`Seeded 14-day history for ${s.code}`);
  }

  console.log("Done.");
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
