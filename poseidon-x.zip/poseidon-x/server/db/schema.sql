-- Poseidon X — schema
-- Run this against a fresh database before seed.sql.

CREATE TABLE IF NOT EXISTS stations (
  code        TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  lat         DOUBLE PRECISION NOT NULL,
  lng         DOUBLE PRECISION NOT NULL,
  score       INTEGER NOT NULL CHECK (score BETWEEN 0 AND 100),
  status      TEXT NOT NULL CHECK (status IN ('good','fair','poor')),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Active, currently-shown alerts
CREATE TABLE IF NOT EXISTS alerts (
  id            SERIAL PRIMARY KEY,
  title         TEXT NOT NULL,
  level         TEXT NOT NULL CHECK (level IN ('HIGH','MEDIUM','LOW')),
  body          TEXT NOT NULL,
  station_code  TEXT NOT NULL REFERENCES stations(code) ON DELETE CASCADE,
  hours_ago     INTEGER NOT NULL DEFAULT 0,
  duration      TEXT NOT NULL DEFAULT '—',
  icon          TEXT NOT NULL DEFAULT 'alert',
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Candidate alerts the live-tick job can rotate into `alerts` to simulate a real-time feed
CREATE TABLE IF NOT EXISTS alert_pool (
  id            SERIAL PRIMARY KEY,
  title         TEXT NOT NULL,
  level         TEXT NOT NULL CHECK (level IN ('HIGH','MEDIUM','LOW')),
  body          TEXT NOT NULL,
  station_code  TEXT NOT NULL REFERENCES stations(code) ON DELETE CASCADE,
  duration      TEXT NOT NULL DEFAULT '—',
  icon          TEXT NOT NULL DEFAULT 'alert'
);

-- Historical daily scores, used for the trend / forecast / compare charts
CREATE TABLE IF NOT EXISTS station_history (
  id            SERIAL PRIMARY KEY,
  station_code  TEXT NOT NULL REFERENCES stations(code) ON DELETE CASCADE,
  day_index     INTEGER NOT NULL,   -- 0 = 14 days ago ... 13 = today
  score         INTEGER NOT NULL CHECK (score BETWEEN 0 AND 100),
  UNIQUE(station_code, day_index)
);

-- Anonymous citizen pollution reports submitted from the Report page
CREATE TABLE IF NOT EXISTS reports (
  id              SERIAL PRIMARY KEY,
  location_name   TEXT NOT NULL,
  lat             DOUBLE PRECISION NOT NULL,
  lng             DOUBLE PRECISION NOT NULL,
  severity        TEXT NOT NULL CHECK (severity IN ('Low','Medium','High')),
  description     TEXT,
  photo_data_url  TEXT,
  status          TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','reviewed','resolved')),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Contributor leaderboard
CREATE TABLE IF NOT EXISTS leaderboard (
  id       SERIAL PRIMARY KEY,
  name     TEXT NOT NULL,
  region   TEXT NOT NULL,
  points   INTEGER NOT NULL DEFAULT 0,
  reports  INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_alerts_created_at ON alerts (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reports_created_at ON reports (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_history_station ON station_history (station_code, day_index);
