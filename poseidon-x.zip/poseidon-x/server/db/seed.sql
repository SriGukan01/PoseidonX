-- Poseidon X — seed data
-- Run after schema.sql. Station history is seeded separately by `npm run seed`
-- (server/scripts/seed-history.js) since it needs the same PRNG the UI charts use.

TRUNCATE reports, alerts, alert_pool, station_history, stations, leaderboard RESTART IDENTITY CASCADE;

INSERT INTO stations (code, name, lat, lng, score, status) VALUES
  ('GOA_01', 'Candolim Coast, Goa',        15.5185, 73.7629, 41, 'poor'),
  ('CHE_01', 'Marina Beach, Chennai',      13.0500, 80.2824, 55, 'fair'),
  ('MUM_02', 'Juhu Shoreline, Mumbai',     19.0989, 72.8265, 33, 'poor'),
  ('KOC_01', 'Vembanad Lake, Kochi',        9.5916, 76.3949, 78, 'good'),
  ('KOL_03', 'Hooghly River, Kolkata',     22.5726, 88.3639, 46, 'fair'),
  ('GOA_02', 'Mandovi Estuary, Goa',       15.4989, 73.8278, 71, 'good'),
  ('VIZ_01', 'RK Beach, Visakhapatnam',    17.7231, 83.3412, 62, 'fair'),
  ('DEL_01', 'Yamuna Ghat, Delhi',         28.6139, 77.2090, 24, 'poor'),
  ('SUR_01', 'Tapi Estuary, Surat',        21.1702, 72.8311, 58, 'fair'),
  ('PUR_01', 'Chilika Lake, Puri',         19.7000, 85.3200, 82, 'good'),
  ('AND_01', 'Radhanagar Beach, Andaman',  11.9694, 92.7422, 91, 'good'),
  ('CHE_02', 'Ennore Creek, Chennai',      13.2167, 80.3167, 29, 'poor');

INSERT INTO alerts (title, level, body, station_code, hours_ago, duration, icon) VALUES
  ('Microplastic Spike', 'HIGH',   'Elevated microplastic density detected along Candolim Coast. Possible runoff after monsoon.', 'GOA_01', 3, '22h', 'flask'),
  ('Turbidity Increase', 'HIGH',   'Increased turbidity levels at Ennore Creek. Possible industrial contamination.', 'CHE_02', 6, '18h', 'droplet'),
  ('Temperature Rise',   'MEDIUM', 'Thermal pollution flagged at Marina Beach. Industrial discharge suspected nearby.', 'CHE_01', 7, '30h', 'sun'),
  ('pH Imbalance',       'MEDIUM', 'Yamuna Ghat readings show sustained pH drop below safe threshold for aquatic life.', 'DEL_01', 9, '40h', 'alert'),
  ('Water Quality Improving', 'LOW', 'Chilika Lake shows a steady rise in dissolved oxygen after cleanup drive.', 'PUR_01', 14, '—', 'shield');

INSERT INTO alert_pool (title, level, body, station_code, duration, icon) VALUES
  ('Dissolved Oxygen Drop', 'HIGH',   'DO levels falling sharply near Juhu Shoreline. Possible organic pollution event.', 'MUM_02', '20h', 'droplet'),
  ('Salinity Fluctuation',  'MEDIUM', 'Unusual salinity swing detected at Vembanad Lake. Monitoring for tidal or discharge cause.', 'KOC_01', '16h', 'flask'),
  ('Algal Bloom Risk',      'MEDIUM', 'Nutrient levels near Hooghly River trending toward bloom conditions.', 'KOL_03', '36h', 'alert'),
  ('Sensor Recalibrated',   'LOW',    'RK Beach buoy recalibrated after routine maintenance; readings now stable.', 'VIZ_01', '—', 'shield'),
  ('Oil Sheen Reported',    'HIGH',   'Citizen report flags a visible oil sheen near Tapi Estuary. Field team dispatched.', 'SUR_01', '12h', 'droplet');

INSERT INTO leaderboard (name, region, points, reports) VALUES
  ('Aarav Mehta',           'Goa',             4820, 61),
  ('Priya Nair',            'Kochi',           4390, 54),
  ('Team Ganga Rakshak',    'Delhi NCR',       4110, 49),
  ('Sanjay Iyer',           'Chennai',         3765, 45),
  ('Coastal Watch Odisha',  'Puri',            3420, 40),
  ('Meera Krishnan',        'Visakhapatnam',   3180, 37);
